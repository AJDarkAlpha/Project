export const SUPABASE_URL = String(import.meta.env.VITE_SUPABASE_URL);
export const SUPABASE_ANON_KEY = String(import.meta.env.VITE_SUPABASE_ANON_KEY);
export const SUPABASE_BUCKET_URL = String(import.meta.env.VITE_SUPABASE_BUCKET_URL);
export const TINYMCE_API_KEY = String(import.meta.env.VITE_TINYMCE_API_KEY);